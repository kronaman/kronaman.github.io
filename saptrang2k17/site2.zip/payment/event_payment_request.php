<?php	

require_once('../connect.php');
function insert_id($table,$id, $request_id){
	global $mysqli;
     $query = "UPDATE ".$table." SET `request_id`= '".$request_id."' WHERE `id` = '".$id."' ";
	if($query_run =mysqli_query($mysqli, $query) ){
		  if(mysqli_affected_rows($mysqli) >=1) {
		  		return true;
			  }
	  }
     
     return false;
}
function insert_in_payment($payer,$request_id){
	global $mysqli;
	$query = "INSERT INTO `payment`(`id`, `user_id`, `request_id`) VALUES ('','".$payer."','".$request_id."')";
      if($query_run =mysqli_query($mysqli, $query) ){
		  if(mysqli_affected_rows($mysqli) >=1) {
		  		return true;
			  }
		  }
     
     return false;
}
	

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.instamojo.com/api/1.1/payment-requests/'); 
//curl_setopt($ch, CURLOPT_URL, 'https://test.instamojo.com/api/1.1/');  //test
curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER,
				array("X-Api-Key:255e6ab093ab061ac2acb1450ed2abf8","X-Auth-Token:8c97377c69976c386e6106b4b99b95e3"));
	$name			=	$_GET['name'];
	$mobile			=	$_GET['phone'];
	$email			=	$_GET['email'];
	$event          =  $_GET['event'];
	$type           =   $_GET['type'];      //s or m
	$id 			=   $_GET['id'];		//   id in db
	$table			=  $_GET['table'];   		//table
	$payer 			=  $_GET['payer'];
	

	if($type=='s') $amount = 150;
	else $amount=600;
	
	
	
$payload = Array(
		'purpose' => $event.' Registration',
		'amount' => $amount,
		'phone' => $mobile,
		'buyer_name' => $name,
		'redirect_url' => 'http://saptrangnitd.com/payment/event_redirect.php',
		'send_email' => false,
		'webhook' => 'http://saptrangnitd.com/payment/return_result.php',
		'send_sms' => false,
		'email' => $email,
		'allow_repeated_payments' => false
	);
//curl_setopt($ch, CURLOPT_POST, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
	$response = curl_exec($ch);
        
	curl_close($ch); 
	$result=json_decode($response,true);
        $request_id = $result["payment_request"]["id"];
	if($result["success"]=="true")
	{
	$longUrl=$result["payment_request"]["longurl"];
        if(insert_id($table,$id,$request_id)&& insert_in_payment($payer,$request_id)){
			header("Location:".$longUrl);
			echo $longUrl;
        }else echo 'Failed';
	
}
	else 
		//echo $response;
                echo 'Payment Failed';
?>