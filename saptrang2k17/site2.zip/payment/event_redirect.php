<?php
require_once('../connect.php');
  $payment_id		=	$_GET['payment_id'];
  $payment_request_id = $_GET['payment_request_id'];


//echo '<center><h2>Registeration Success</h2><br>  <h3>Your Payment ID is '.$payment_id.'. Please Note it for future reference. Thanks</h3></center>';
header("Location : payment_status.php?pid=$payment_id&prid=$payment_request_id");

?>

<center><a href="http://saptrangnitd.com">Home</a></center>