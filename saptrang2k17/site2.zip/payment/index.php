<?php
require_once('../connect.php');
  $payment_id		=	$_GET['payment_id'];
  $payment_request_id = $_GET['payment_request_id'];

$query = "SELECT * FROM `payment` WHERE `request_id`='".$payment_request_id."'";
if($query_run = mysqli_query($mysqli, $query)){
		$row = mysqli_fetch_assoc($query_run);
		$user_id = $row['user_id'];
	
	header("Location : payment_status_acc.php?pid=$payment_id&prid=$payment_request_id&user_id=$user_id");	
	/*echo '<center><h2>Registeration Success</h2><br>  <h3>Your User ID is SPT-'.$user_id.' and Payment ID is '.$payment_id.'. Please Note them for future reference. Thanks</h3></center>';*/
	}

?>

<center><a href="http://saptrangnitd.com">Home</a></center>