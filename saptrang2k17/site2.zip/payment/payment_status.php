<?php

$ch = curl_init();
$pid = $_GET['pid'];
$prid = $_GET['prid'];


curl_setopt($ch, CURLOPT_URL, "https://www.instamojo.com/api/1.1/payment-requests/$prid/$pid/");
curl_setopt($ch, CURLOPT_HEADER, FALSE);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
curl_setopt($ch, CURLOPT_HTTPHEADER,
            array("X-Api-Key:255e6ab093ab061ac2acb1450ed2abf8",
                  "X-Auth-Token:8c97377c69976c386e6106b4b99b95e3"));
$payload = Array(
    'purpose' => 'FIFA 16',
    'amount' => '2500',
    'phone' => '9999999999',
    'buyer_name' => 'John Doe',
    'redirect_url' => 'http://www.example.com/redirect/',
    'send_email' => true,
    'webhook' => 'http://www.example.com/webhook/',
    'send_sms' => true,
    'email' => 'foo@example.com',
    'allow_repeated_payments' => false
);
$response = curl_exec($ch);
$result=json_decode($response,true);
$payment= $result['payment_request']['payment'];
$status = $payment['status'];
if($status == 'Credit'){
	echo '<center><h2>Registeration Success</h2><br>  <h3>Your Payment ID is '.$pid.'. Please Note it for future reference. Thanks</h3></center>';
}else{
	echo '<center><h2>Payment Failed</h2><br>  <h3>Your Payment ID is '.$pid.'. Please Note it for future reference. Thanks</h3></center>';
}
curl_close($ch); 



?>
<html>
	<center><a href="http://saptrangnitd.com">Home</a></center>
</html>