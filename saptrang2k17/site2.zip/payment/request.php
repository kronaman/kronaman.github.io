<?php	

require_once('../connect.php');
function insert_id($user_id, $request_id){
      global $mysqli;
      $query = "INSERT INTO `payment`(`id`, `user_id`, `request_id`) VALUES ('','".$user_id."','".$request_id."') ";
      if($query_run =mysqli_query($mysqli, $query) ){
                if(mysqli_affected_rows($mysqli) >=1) return true;
     }
     return false;
}
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://www.instamojo.com/api/1.1/payment-requests/'); 
//curl_setopt($ch, CURLOPT_URL, 'https://test.instamojo.com/api/1.1/');  //test
curl_setopt($ch, CURLOPT_HEADER, FALSE);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	//curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
	curl_setopt($ch, CURLOPT_HTTPHEADER,
				array("X-Api-Key:255e6ab093ab061ac2acb1450ed2abf8","X-Auth-Token:8c97377c69976c386e6106b4b99b95e3"));
	$name			=	$_GET['name'];
	$institute		=	$_GET['college'];
	$mobile			=	$_GET['phone'];
	$email			=	$_GET['email'];
    $user_id = $_GET['user_id'];
	$type = $_GET['type'];

	$amount = 150;
	if($type == 'acm')	$amount=500;
	
	
$payload = Array(
		'purpose' => 'Saptrang  Accomodation',
		'amount' => $amount,
		'phone' => $mobile,
		'buyer_name' => $name,
		'redirect_url' => 'http://saptrangnitd.com/payment/',
		'send_email' => false,
		'webhook' => 'http://saptrangnitd.com/payment/return_result.php',
		'send_sms' => false,
		'email' => $email,
		'allow_repeated_payments' => false
	);
//curl_setopt($ch, CURLOPT_POST, false);
	curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
	$response = curl_exec($ch);
         echo $response.'   ';
	curl_close($ch); 
	$result=json_decode($response,true);
        $request_id = $result["payment_request"]["id"];
	if($result["success"]=="true")
	{
	$longUrl=$result["payment_request"]["longurl"];
        if(insert_id($user_id, $request_id)){
                   header("Location:".$longUrl);
        }else echo 'Failed';
	
}
	else 
		echo $response;
                echo 'Payment Failed';
?>