<?php
/*
Basic PHP script to handle Instamojo RAP webhook.
*/
require_once('../connect.php');
$data = $_POST;
$mac_provided = $data['mac'];  // Get the MAC from the POST data
unset($data['mac']);  // Remove the MAC key from the data.
$ver = explode('.', phpversion());
$major = (int) $ver[0];
$minor = (int) $ver[1];
if($major >= 5 and $minor >= 4){
     ksort($data, SORT_STRING | SORT_FLAG_CASE);
}
else{
     uksort($data, 'strcasecmp');
}
// You can get the 'salt' from Instamojo's developers page(make sure to log in first): https://www.instamojo.com/developers
// Pass the 'salt' without <>
$mac_calculated = hash_hmac("sha1", implode("|", $data), "9e52540789a949c09fe5b4403dc35cbb");
//$mac_calculated = hash_hmac("sha1", implode("|", $data), "c7b96386407b46b3a9767f287fe0a168");  //test
if($mac_provided == $mac_calculated){
    if($data['status'] == "Credit"){
        // Payment was successful, mark it as successful in your database.
        // You can acess payment_request_id, purpose etc here. 
		$payment_id = $data['payment_id'];
		$payment_request_id = $data['payment_request_id'];
		$amount = $data['amount'];
		$query = "UPDATE `payment` SET `payment_id`= '".$payment_id."',`status`= 'success', `amount`='".$amount."' WHERE `request_id` = '".$payment_request_id."'";
		$query_run = mysqli_query($mysqli, $query);
    }
    else{
        // Payment was unsuccessful, mark it as failed in your database.
        // You can acess payment_request_id, purpose etc here.
		$payment_id = $data['payment_id'];
		$payment_request_id = $data['payment_request_id'];
		
        $query = "UPDATE `payment` SET `payment_id`= '".$payment_id."',`status`= 'fail' WHERE `request_id` = '".$payment_request_id."'";
		$query_run = mysqli_query($mysqli, $query);
    }
}
else{
    echo "MAC mismatch";
}
?>