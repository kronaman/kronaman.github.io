<center>
	<h2>Registration has been stopped for some moment due to some technical Problem.</h2><br><br>
	<h3>Sorry For Inconvenience.</h3>
</center>